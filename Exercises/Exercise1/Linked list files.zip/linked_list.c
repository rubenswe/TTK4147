#include <stdlib.h>
#include <stdio.h>
#include "linked_list.h"

list_t list_create()
{

}

void list_delete(list_t list)
{

}

void list_insert(list_t list, int index, int data)
{

}

void list_append(list_t list, int data)
{

}

void list_print(list_t list)
{

}

long list_sum(list_t list)
{

}

int list_get(list_t list, int index)
{

}

int list_extract(list_t list, int index)
{

}
